package functions

import (
	"encoding/json"
	"fmt"
	"html"
	"io"
	"log"
	"net/http"
)

func PointMe(w http.ResponseWriter, r *http.Request) {
	var s struct{
		Message string `json:"message"`
	}
	if err:= json.NewDecoder(r.Body).Decode(&s); err != nil {
		switch err {
		case io.EOF:
			fmt.Fprint(w, "Default: Hello World!")
			return
		default:
			log.Printf("json.NewDecoder: %v", err)
			http.Error(w, http.StatusText(http.StatusBadRequest), http.StatusBadRequest)
			return
		}
	}
	if s.Message == "" {
		fmt.Fprint(w, "Default: Hello World!")
		return
	}

	for i := 0; i <= len(s.Message); i++ {
		fmt.Fprint(w, html.EscapeString(s.Message[:i]))
		fmt.Fprint(w, "\n")
	}
}
